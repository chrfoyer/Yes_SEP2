package viewmodel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

@SuppressWarnings("ALL")
class AddEditGameViewModelTest
{

    @BeforeEach
    void setUp()
    {
    }


    @Test
    void addGame()
    {
    }

    @Test
    void editGame()
    {
    }
}